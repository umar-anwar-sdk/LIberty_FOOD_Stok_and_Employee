from django.contrib import admin
from .models import (
    Category, Dealer, FoodItem, Customer,
    Order, OrderItem,
    Employee, EmployeeSalary, EmployeeTransaction
)


# ---------------- CATEGORY ----------------
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name")
    search_fields = ("name",)


# ---------------- DEALER ----------------
@admin.register(Dealer)
class DealerAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "contact_info")
    search_fields = ("name", "contact_info")


# ---------------- FOOD ITEM ----------------
@admin.register(FoodItem)
class FoodItemAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "price", "category", "dealer")
    list_filter = ("category", "dealer")
    search_fields = ("name", "description")


# ---------------- CUSTOMER ----------------
@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "phone", "address")
    search_fields = ("name", "phone")


# ---------------- ORDER ----------------
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 1


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "customer", "order_date")
    list_filter = ("order_date",)
    inlines = [OrderItemInline]


# ---------------- EMPLOYEE ----------------
@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ("id", "first_name", "last_name", "position", "base_salary", "join_date")
    search_fields = ("first_name", "last_name", "position")
    list_filter = ("position", "join_date")


# ---------------- EMPLOYEE SALARY ----------------
@admin.register(EmployeeSalary)
class EmployeeSalaryAdmin(admin.ModelAdmin):
    list_display = ("id", "employee", "month", "total_salary", "remaining_salary", "advance_amount")
    list_filter = ("month", "employee")
    search_fields = ("employee__first_name", "employee__last_name")


# ---------------- EMPLOYEE TRANSACTION ----------------
@admin.register(EmployeeTransaction)
class EmployeeTransactionAdmin(admin.ModelAdmin):
    list_display = ("id", "employee", "salary_record", "transaction_type", "amount", "reason", "date")
    list_filter = ("transaction_type", "date")
    search_fields = ("employee__first_name", "employee__last_name", "reason")
