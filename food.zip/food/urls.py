from django.urls import path
from . import views
from . import auth_view

urlpatterns = [
    # Home
    path("", views.home, name="home"),
    # Authentication
    path("signup/", auth_view.signup, name="signup"),
    path("login/", auth_view.user_login, name="login"),
    path("logout/", auth_view.logout_view, name="logout"),
    # Categories and Dealers
    path("add_category/", views.add_category, name="add_category"),
    path("category_edit/<int:pk>/", views.category_edit, name="category_edit"),
    path("category_delete/<int:pk>/", views.category_delete, name="category_delete"),
    path("category_list/", views.category_list, name="category_list"),
    path("add_dealer/", views.add_delealer, name="add_dealer"),
    # Food Items
    path("food_quantity/", views.add_food_quantity, name="food_quantity"),
    path("foods/", views.fooditem_list, name="fooditem_list"),
    path("foods/<int:pk>/", views.fooditem_detail, name="fooditem_detail"),
    path("foods/add/", views.fooditem_add, name="fooditem_add"),
    path("foods/<int:pk>/edit/", views.fooditem_edit, name="fooditem_edit"),
    path("foods/<int:pk>/delete/", views.fooditem_delete, name="fooditem_delete"),

    # Customers
    path("customers/", views.customer_list, name="customer_list"),
    path("customers/add/", views.customer_add, name="customer_add"),

    # Orders
    path("orders/add/", views.create_order, name="order_add"),
    path("orders/<int:pk>/", views.order_detail, name="order_detail"),
    path("orders/<int:pk>/edit/", views.order_edit, name="order_edit"),
    path("orders/<int:pk>/delete/", views.order_delete, name="order_delete"),
    path("orders/", views.order_list, name="order_list"),

    # Employees
    path("employees/", views.employee_list, name="employee_list"),
    path("employees/add/", views.employee_add, name="employee_add"),
    path("employees/<int:employee_id>/end/", views.end_job, name="end_job"),
    path("employees/<int:employee_id>/calculate_salary/", views.calculate_salary, name="calculate_salary"),
    path("employees/<int:employee_id>/", views.employee_detail, name="employee_detail"),

]
