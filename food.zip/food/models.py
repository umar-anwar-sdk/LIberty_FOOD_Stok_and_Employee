from django.db import models


from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin, Group, Permission
from django.db import models

class CustomUserManager(BaseUserManager):
    def create_user(self, email, first_name, last_name, password=None):
        if not email:
            raise ValueError("Users must have an email address")
        
        email = self.normalize_email(email)
        user = self.model(email=email, first_name=first_name, last_name=last_name)
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email, first_name, last_name, password=None):
        user = self.create_user(email, first_name, last_name, password)
        user.is_admin = True
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user

class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    
    groups = models.ManyToManyField(Group, related_name="customuser_set", blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name="customuser_permissions_set", blank=True)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    def __str__(self):
        return self.email



class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Dealer(models.Model):
    name = models.CharField(max_length=100)
    contact_info = models.TextField()

    def __str__(self):
        return self.name


class FoodItem(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    category = models.ForeignKey("Category", on_delete=models.CASCADE)
    dealer = models.ForeignKey("Dealer", on_delete=models.SET_NULL, null=True, blank=True)
    image = models.ImageField(upload_to="food_images/", null=True, blank=True)

    # NEW FIELD
    quantity = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.name} (Quantity: {self.quantity})"
class StockTransaction(models.Model):
    food_item = models.ForeignKey(FoodItem, on_delete=models.CASCADE, related_name="stock_transactions")
    quantity = models.IntegerField()  # +ve = stock in, -ve = stock out
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.food_item.name} | {self.quantity} on {self.created_at.date()}"




class Customer(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    phone = models.CharField(max_length=20, null=True, blank=True)

    def __str__(self):
        return self.name


class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    order_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order #{self.id} - {self.customer.name}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name="items", on_delete=models.CASCADE)
    food_item = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} x {self.food_item.name}"

from django.utils.timezone import now
class Employee(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    position = models.CharField(max_length=100)
    join_date = models.DateTimeField()
    is_active = models.BooleanField(default=True) 
    base_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0,null=True, blank=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class EmployeeDailyCash(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="daily_cash_records")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField()
    date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.employee} - {self.amount} on {self.date}"



from django.utils import timezone
class EmployeeSalary(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="salaries")
    month = models.DateField(default=timezone.now)
    total_salary = models.DecimalField(max_digits=10, decimal_places=2)
    remaining_salary = models.DecimalField(max_digits=10, decimal_places=2)
    advance_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.employee} - {self.month.strftime('%B %Y')}"


class EmployeeTransaction(models.Model):
    TRANSACTION_TYPES = (
        ("taken", "Cash Taken"),
        ("deposit", "Cash Deposit"),
    )
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="transactions")
    salary_record = models.ForeignKey(EmployeeSalary, on_delete=models.CASCADE, related_name="transactions")
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField(null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.employee} - {self.transaction_type} {self.amount} on {self.date.date()}"