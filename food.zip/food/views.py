from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.utils.timezone import now
import calendar

from decimal import Decimal
from django.db.models import Sum


from .models import (
    Category, Dealer, FoodItem,
    Customer, Order, OrderItem,
    Employee, EmployeeSalary, EmployeeTransaction
)

# ---------------- FOOD ITEMS ---------------- #
def home(request):
    return render(request, "base.html")

def fooditem_list(request):
    items = FoodItem.objects.all()
    return render(request, "fooditem_list.html", {"items": items})


def add_delealer(request):
    if request.method == "POST":
        name = request.POST.get("name")
        contact_info = request.POST.get("contact_info")
        Dealer.objects.create(name=name, contact_info=contact_info)
        return redirect("add_dealer")
    return render(request, "add_dealer.html")
def add_category(request):
    if request.method == "POST":
        name = request.POST.get("name")
        Category.objects.create(name=name)
        return redirect("add_category")
    return render(request, "add_category.html")
def category_list(request):
    categories = Category.objects.all()
    return render(request, "category_list.html", {"categories": categories})

def category_edit(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == "POST":
        category.name = request.POST.get("name")
        category.save()
        return redirect("category_list")
    return render(request, "category_edit.html", {"category": category})
def category_delete(request, pk):
    get_object_or_404(Category, pk=pk).delete()
    return redirect('category_list')


def fooditem_detail(request, pk):
    item = get_object_or_404(FoodItem, pk=pk)
    return render(request, "fooditem_detail.html", {"item": item})

def fooditem_add(request):
    if request.method == "POST":
        name = request.POST.get("name")
        description = request.POST.get("description")
        price = request.POST.get("price")
        category_id = request.POST.get("category")
        dealer_id = request.POST.get("dealer")
        image = request.FILES.get("image")

        category = get_object_or_404(Category, id=category_id)
        dealer = Dealer.objects.filter(id=dealer_id).first() if dealer_id else None

        FoodItem.objects.create(
            name=name,
            description=description,
            price=price,
            category=category,
            dealer=dealer,
            image=image
        )
        return redirect("fooditem_list")

    categories = Category.objects.all()
    dealers = Dealer.objects.all()
    return render(
        request,
        "fooditem_form.html",
        {"categories": categories, "dealers": dealers}
    )


def fooditem_edit(request, pk):
    item = get_object_or_404(FoodItem, pk=pk)
    if request.method == "POST":
        item.name = request.POST.get("name")
        item.description = request.POST.get("description")
        item.price = request.POST.get("price")
        item.category_id = request.POST.get("category")
        item.dealer_id = request.POST.get("dealer")
        item.save()
        return redirect("fooditem_list")

    categories = Category.objects.all()
    dealers = Dealer.objects.all()
    return render(request, "fooditem_form.html", {"item": item, "categories": categories, "dealers": dealers})


def fooditem_delete(request, pk):
    item = get_object_or_404(FoodItem, pk=pk)
    if request.method == "POST":
        item.delete()
        return redirect("fooditem_list")
    return render(request, "fooditem_confirm_delete.html", {"item": item})


def add_food_quantity(request):
    if request.method == "POST":
        food_item_id = request.POST.get("food_item")
        quantity = int(request.POST.get("quantity", 0))

        food_item = get_object_or_404(FoodItem, id=food_item_id)
        food_item.quantity += quantity
        food_item.save()

        return redirect("fooditem_list")

    items = FoodItem.objects.all()
    return render(request, "add_stock.html", {"items": items})


# ---------------- CUSTOMERS ---------------- #
def customer_list(request):
    customers = Customer.objects.all()
    return render(request, "customer_list.html", {"customers": customers})


def customer_add(request):
    if request.method == "POST":
        name = request.POST.get("name")
        address = request.POST.get("address")
        phone = request.POST.get("phone")
        Customer.objects.create(name=name, address=address, phone=phone)
        return redirect("customer_list")
    return render(request, "customer_form.html")


# ---------------- ORDERS ---------------- #

def create_order(request):
    customers = Customer.objects.all()
    food_items = FoodItem.objects.all()

    if request.method == "POST":
        customer_id = request.POST.get("customer")
        food_item_id = request.POST.get("food_item")
        quantity = int(request.POST.get("quantity"))

        customer = get_object_or_404(Customer, id=customer_id)
        food_item = get_object_or_404(FoodItem, id=food_item_id)

        # stock check
        if food_item.quantity < quantity:
            messages.error(request, f"⚠ Only {food_item.quantity} {food_item.name} available in stock!")
            return redirect("order_list")

        # Order create
        order = Order.objects.create(customer=customer)

        # OrderItem create
        OrderItem.objects.create(order=order, food_item=food_item, quantity=quantity)

        # Stock update
        food_item.quantity -= quantity
        food_item.save()

        messages.success(request, f"✅ Order created successfully. {quantity} {food_item.name} deducted from stock.")
        return redirect("order_list")

    return render(request, "create_order.html", {
        "customers": customers,
        "food_items": food_items
    })


def order_edit(request, pk):
    order = get_object_or_404(Order, pk=pk)
    if request.method == "POST":
        customer_id = request.POST.get("customer")
        food_item_id = request.POST.get("food_item")
        quantity = int(request.POST.get("quantity", 1))

        order.customer_id = customer_id
        order.save()

        order_item = order.items.first()
        if order_item:
            order_item.food_item_id = food_item_id
            order_item.quantity = quantity
            order_item.save()
        else:
            OrderItem.objects.create(order=order, food_item_id=food_item_id, quantity=quantity)

        return redirect("order_detail", pk=order.pk)
def order_list(request):
    orders = Order.objects.all()
    return render(request, "order_list.html", {"orders": orders})
def order_delete(request, pk):
    order = get_object_or_404(Order, pk=pk)
    if request.method == "POST":
        order.delete()
        return redirect("order_list")
   
def order_detail(request, pk):
    order = get_object_or_404(Order, pk=pk)
    items = OrderItem.objects.filter(order=order)
    order_data = []
    total = 0
    for item in items:
        subtotal = item.food_item.price * item.quantity
        total += subtotal
        order_data.append({
            "name": item.food_item.name,
            "quantity": item.quantity,
            "price": item.food_item.price,
            "subtotal": subtotal,
        })

    return render(request, "order_detail.html", {
        "order": order,
        "items": order_data,  
        "total": total,
    })


# ---------------- EMPLOYEES ---------------- #
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, "employee_list.html", {"employees": employees})


from datetime import datetime
def employee_add(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        position = request.POST.get("position")
        salary_input = request.POST.get("salary")
        join_date_input = request.POST.get("join_date")  # yyyy-mm-dd format expected

        # validate salary
        try:
            salary = Decimal(salary_input)
        except (TypeError, ValueError):
            salary = Decimal("0")

        # convert join_date string to date object
        join_date = None
        if join_date_input:
            try:
                join_date = datetime.strptime(join_date_input, "%Y-%m-%d").date()
            except ValueError:
                join_date = now().date()

        # create employee
        employee = Employee.objects.create(
            first_name=first_name,
            last_name=last_name,
            position=position,
            base_salary=salary,
            join_date=join_date
        )

        # salary calculation
        today = now().date()
        month_start = today.replace(day=1)
        total_days_in_month = calendar.monthrange(today.year, today.month)[1]

        per_day_salary = salary / Decimal(total_days_in_month)

        if join_date and join_date >= month_start:
            worked_days = total_days_in_month - join_date.day + 1
            monthly_salary = per_day_salary * Decimal(worked_days)
        else:
            monthly_salary = salary

        # salary record create
        EmployeeSalary.objects.create(
            employee=employee,
            month=month_start,
            total_salary=monthly_salary,
            remaining_salary=monthly_salary,
            advance_amount=Decimal("0"),
        )

        return redirect("employee_list")

    return render(request, "employee_form.html")


def calculate_salary(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)

    context = {
        "employee": employee,
        "calculated_salary": None,
        "advance_used": None,
        "remaining_salary": None,
        "period": None,
        "transactions": EmployeeTransaction.objects.filter(employee=employee).order_by("-date"),
    }

    if request.method == "POST":
        from_date = parse_date(request.POST.get("from_date"))
        to_date = parse_date(request.POST.get("to_date"))

        if from_date and to_date:
            # daily salary = base_salary / 30 (fixed month length)
            daily_salary = employee.base_salary / Decimal(30)

            # total worked days
            days = (to_date - from_date).days + 1
            if days < 0:
                days = 0

            calculated_salary = daily_salary * days

            # advance/cash taken in this period
            advance_used = EmployeeTransaction.objects.filter(
                employee=employee,
                transaction_type="taken",
                date__date__range=[from_date, to_date]
            ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

            # remaining salary after advance deduction
            remaining_salary = calculated_salary - advance_used

            context.update({
                "calculated_salary": calculated_salary,
                "advance_used": advance_used,
                "remaining_salary": remaining_salary,
                "period": f"{from_date} to {to_date}",
            })

    return render(request, "employee_detail.html", context)

from django.utils.dateparse import parse_date


def employee_detail(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)

    today = now().date()
    month_start = today.replace(day=1)
    total_days_in_month = calendar.monthrange(today.year, today.month)[1]
    monthly_salary = employee.base_salary

    # join_date handle
    join_date = employee.join_date
    if hasattr(join_date, "date"):
        join_date = join_date.date()

    if join_date and join_date >= month_start:
        per_day_salary = employee.base_salary / Decimal(total_days_in_month)
        worked_days = total_days_in_month - join_date.day + 1
        monthly_salary = per_day_salary * Decimal(worked_days)

    # Salary record
    salary_record, created = EmployeeSalary.objects.get_or_create(
        employee=employee,
        month=month_start,
        defaults={
            "total_salary": monthly_salary,
            "remaining_salary": monthly_salary,
            "advance_amount": Decimal("0"),
        },
    )

    if request.method == "POST":
        if "action" in request.POST:  # transaction form
            action = request.POST.get("action")
            try:
                amount = Decimal(request.POST.get("amount", "0"))
            except (TypeError, ValueError):
                amount = Decimal("0")
            reason = request.POST.get("reason", "")

            if amount <= 0:
                messages.error(request, "Invalid amount entered.")
                return redirect("employee_detail", employee_id=employee.id)

            if action == "taken":
                if salary_record.remaining_salary >= amount:
                    salary_record.remaining_salary -= amount
                else:
                    extra = amount - salary_record.remaining_salary
                    salary_record.remaining_salary = Decimal("0")
                    salary_record.advance_amount += extra

                EmployeeTransaction.objects.create(
                    employee=employee,
                    salary_record=salary_record,
                    transaction_type="taken",
                    amount=amount,
                    reason=reason,
                )
                messages.success(request, f"{amount} cash taken successfully!")

            elif action == "deposit":
                if salary_record.advance_amount > 0:
                    if amount <= salary_record.advance_amount:
                        salary_record.advance_amount -= amount
                    else:
                        extra = amount - salary_record.advance_amount
                        salary_record.advance_amount = Decimal("0")
                        salary_record.remaining_salary += extra
                else:
                    salary_record.remaining_salary += amount

                EmployeeTransaction.objects.create(
                    employee=employee,
                    salary_record=salary_record,
                    transaction_type="deposit",
                    amount=amount,
                    reason=reason,
                )
                messages.success(request, f"{amount} cash deposited successfully!")

            else:
                messages.error(request, "Invalid action.")
                return redirect("employee_detail", employee_id=employee.id)

            salary_record.save()
            return redirect("employee_detail", employee_id=employee.id)

        elif "from_date" in request.POST and "to_date" in request.POST:  
            from_date = parse_date(request.POST.get("from_date"))
            to_date = parse_date(request.POST.get("to_date"))

            if from_date and to_date:
                daily_salary = employee.base_salary / Decimal(30)
                days = (to_date - from_date).days + 1
                if days < 0:
                    days = 0

                calculated_salary = daily_salary * days

                advance_used = EmployeeTransaction.objects.filter(
                    employee=employee,
                    transaction_type="taken",
                    date__date__range=[from_date, to_date]
                ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

                remaining_salary = calculated_salary - advance_used

                request.session["salary_result"] = {
                    "period": f"{from_date} to {to_date}",
                    "calculated_salary": str(calculated_salary),
                    "advance_used": str(advance_used),
                    "remaining_salary": str(remaining_salary),
                }

            return redirect("employee_detail", employee_id=employee.id)
    try:
        transactions = salary_record.transactions.all().order_by("-date")
    except AttributeError:
        transactions = EmployeeTransaction.objects.filter(
            salary_record=salary_record
        ).order_by("-date")

    total_taken = EmployeeTransaction.objects.filter(
        salary_record=salary_record, transaction_type="taken"
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

    total_deposit = EmployeeTransaction.objects.filter(
        salary_record=salary_record, transaction_type="deposit"
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

    summary = {
        "total_salary": salary_record.total_salary,
        "worked_days_salary": monthly_salary,
        "advance": salary_record.advance_amount,
        "deposit": total_deposit,
        "remaining": salary_record.remaining_salary,
    }
    salary_result = request.session.pop("salary_result", None)

    return render(request, "employee_detail.html", {
        "employee": employee,
        "salary_record": salary_record,
        "transactions": transactions,
        "summary": summary,
        "salary_result": salary_result,
    })


def end_job(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    employee.is_active = False  
    employee.save()
    messages.success(request, f"{employee.first_name} {employee.last_name} ka job end kar diya gaya.")
    return redirect("employee_detail", employee_id=employee.id)








